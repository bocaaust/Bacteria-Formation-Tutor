//
//  main.m
//  Bacteria Formation Tutor
//
//  Created by Austin Lubetkin on Monday, May 8, 2017
//  Copyright (c) Austin Lubetkin. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
